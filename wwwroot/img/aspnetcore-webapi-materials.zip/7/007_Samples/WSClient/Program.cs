﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace WSClient
{
    class Program
    {
        private static HubConnection connection;

        async static Task Main(string[] args)
        {
            connection = new HubConnectionBuilder()
                .WithUrl("http://localhost:5000/notification")
                .WithAutomaticReconnect()
                .Build();
            
            connection.On<string>("ReceiveMessage", (message) =>
            {
                var newMessage = $"{DateTime.Now.ToShortTimeString()}: {message}";
                Console.WriteLine(newMessage);
            });

            try
            {
                await connection.StartAsync();
                Console.WriteLine("Connction Started");
                await WaitForMessages();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private async static Task WaitForMessages()
        {
            while (true)
            {
                try
                {
                    Console.Write("You say: ");
                    var message = Console.ReadLine();
                    await connection.InvokeAsync("SendMessageToAllUsers", message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }
    }
}
