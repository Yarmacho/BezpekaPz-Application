﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace WebBrowser
{
    class Program
    {
        static async Task Main(string[] args)
        {
            //MainAsync(args).ConfigureAwait(false).GetAwaiter().GetResult();
            #region TCP
            TCP();
            #endregion

            #region HttpClient
            // HttpClient client = new HttpClient();
            // client.BaseAddress = new Uri("http://google.com/");
            // client.DefaultRequestHeaders.Accept.Clear();
            // client.DefaultRequestHeaders.Accept.Add(
            //     new MediaTypeWithQualityHeaderValue("*/*"));
            // System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            // byte[] credentialsBytes1 = System.Text.Encoding.UTF8.GetBytes("mtsy:Vanmxpx21");
            // string credentialsBase641 = Convert.ToBase64String(credentialsBytes1);
            // client.DefaultRequestHeaders.ProxyAuthorization =
            //     new AuthenticationHeaderValue("Basic", credentialsBase641);
            // Console.WriteLine(client.DefaultRequestHeaders.ToString());
            // var res = await client.GetAsync("/");

            // Console.WriteLine(res.ToString());
            #endregion
            /** Sockets */
            List<string> headers = new List<string>();
            try
            {
                using(HTTPSocket socket = new HTTPSocket("echo.websocket.org", 80)) // HTTPSocket, SSLSocket
                {
                    socket.Connect();

                    byte[] credentialsBytes = System.Text.Encoding.UTF8.GetBytes("mtsy:Vanmxpx21");
                    string credentialsBase64 = Convert.ToBase64String(credentialsBytes);
                    headers.Add($"Proxy-Authorization: Basic {credentialsBase64}");
                    headers.Add("Connection: keep-alive");
                    headers.Add("Accept: */*");

                    socket.Get(headers);
                }

                //int bytesSent = socket.Send(Encoding.ASCII.GetBytes(requestData));
                //int bytesRec = socket.Receive(bytes);

                //Console.WriteLine("Received {0} bytes: {1}", bytesRec, Encoding.ASCII.GetString(bytes, 0, bytesRec));
            }
            catch (ArgumentNullException ane)
            {
                Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
            }
            catch (SocketException se)
            {
                Console.WriteLine("SocketException : {0}", se.ToString());
            }
            catch (Exception e)
            {
                Console.WriteLine("Unexpected exception : {0}", e.ToString());
            }
        }

        private static void TCP()
        {
            // TcpClient client = new TcpClient("habr.com", 443);

            // Console.WriteLine("Client connected.");

            // // Create an SSL stream that will close the client's stream.
            // SslStream sslStream = new SslStream(
            //     client.GetStream(), false,
            //     new RemoteCertificateValidationCallback(ValidateServerCertificate), null);
            // // The server name must match the name on the server certificate.

            // try
            // {
            //     sslStream.AuthenticateAsClient("");
            // }
            // catch (AuthenticationException e)
            // {
            //     Console.WriteLine("Exception: {0}", e.Message);
            //     if (e.InnerException != null)
            //     {
            //         Console.WriteLine("Inner exception: {0}", e.InnerException.Message);
            //     }
            //     Console.WriteLine("Authentication failed - closing the connection.");
            //     client.Close();
            //     return;
            // }

            try
            {
                IPHostEntry ipHostEntry = Dns.GetHostEntry("habr.com");
                IPAddress ipAddress = ipHostEntry.AddressList[0];
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, 80);

                TcpClient client = new TcpClient(remoteEP);

                NetworkStream ns = client.GetStream();

                byte[] bytes = new byte[1024];
                StringBuilder dataComplier = new StringBuilder();
                dataComplier.AppendLine("GET / HTTP/1.1");
                dataComplier.AppendLine($"Host: {client.ToString()}");
                List<string> headers1 = new List<string>();
                byte[] credentialsBytes = System.Text.Encoding.UTF8.GetBytes("mtsy:Vanmxpx21");
                string credentialsBase64 = Convert.ToBase64String(credentialsBytes);
                headers1.Add($"Proxy-Authorization: Basic {credentialsBase64}");
                headers1.Add("Connection: keep-alive");
                headers1.Add("Accept: text/html");
                headers1.ForEach(h => dataComplier.AppendLine(h));
                dataComplier.AppendLine($"User-Agent: {Assembly.GetExecutingAssembly().GetName().Name}");
                dataComplier.AppendLine("");

                string requestData = dataComplier.ToString();

                ns.Write(Encoding.ASCII.GetBytes(requestData));

                int bytesRec = ns.Read(bytes, 0, bytes.Length);
                string result = Encoding.ASCII.GetString(bytes, 0, bytesRec);

                Console.WriteLine("TCP Received {0} bytes: {1}", bytesRec, result);

                client.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private static bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        // async static Task Main(string[] args)
        // {
        //     /** HttpClient */
        //     // HttpClient http = new HttpClient();

        //     // HttpResponseMessage response = await http.GetAsync("http://www.habr.com/");

        //     // string pageContent = await response.Content.ReadAsStringAsync();

        //     // Console.Write(pageContent);

        //     Console.ReadLine();
        // }

    }
}