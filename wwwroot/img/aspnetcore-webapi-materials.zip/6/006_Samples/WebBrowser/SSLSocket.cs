using System;
using System.Collections.Generic;
using System.Net.Security;
using System.Net.Sockets;
using System.Text;

namespace WebBrowser
{
    public class SSLSocket : HTTPSocket
    {
        private SslStream sslStream;
        private NetworkStream networkStream;
        public SSLSocket(string host, int port) : base(host, port) { }

        public override void Connect()
        {
            base.Connect();
            networkStream = new NetworkStream(socket);
            sslStream = new SslStream(new NetworkStream(socket), false);
            sslStream.AuthenticateAsClient(host);
        }
        protected override string SendReceive(byte[] request)
        {
            sslStream.Write(request);
            int bytesRec = sslStream.Read(bytes);
            
            return FormatResult(bytes, bytesRec);
        }

        protected override void Dispose(bool disposing)
        {
            if (sslStream != null && disposedValue && disposing)
                sslStream.Dispose();

            base.Dispose(disposing);
        }
    }
}