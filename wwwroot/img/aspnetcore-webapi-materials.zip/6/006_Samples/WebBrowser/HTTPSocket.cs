using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;

namespace WebBrowser
{
    public class HTTPSocket : IDisposable
    {
        protected IPEndPoint remoteEP;
        protected Socket socket;
        protected string host;
        // Recieved data
        protected byte[] bytes = new byte[1024];
        protected StringBuilder dataComplier = new StringBuilder();
        public HTTPSocket(string host, int port)
        {
            this.host = host;
            // Establish new endpoint
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host);
            IPAddress ipAddress = ipHostEntry.AddressList[0];
            remoteEP = new IPEndPoint(ipAddress, port);

            // Create a TCP/IP Socket 
            socket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
        }

        public virtual void Connect()
        {
            socket.Connect(remoteEP);
            // socket.Bind(remoteEP);
            // socket.Listen(4);
            string re = socket.RemoteEndPoint.ToString();
            Console.WriteLine("Socket connected to {0}", re);

        }
        public virtual string Get(List<string> headers)
        {
            string result = string.Empty;

            dataComplier.AppendLine("GET / HTTP/1.1");
            dataComplier.AppendLine($"Host: {host}");
            headers.Add("Connection: keep-alive");
            dataComplier.AppendLine("Accept: */*");
            headers.ForEach(h => dataComplier.AppendLine(h));
            dataComplier.AppendLine($"User-Agent: {Assembly.GetExecutingAssembly().GetName().Name}");
            dataComplier.AppendLine("");
            string requestData = dataComplier.ToString();

            Console.WriteLine("Request: {0}", requestData);
            byte[] sendBytes = Encoding.ASCII.GetBytes(requestData);
            result = SendReceive(sendBytes);

            return result;
        }

        protected virtual string SendReceive(byte[] requestData)
        {
            int bytesSent = socket.Send(requestData);
            int bytesRec = socket.Receive(bytes);
            List<byte> buffer = new List<byte>(bytes);

            byte[] load;
            while (socket.Available > 0)
            {
                load = new byte[socket.Available];
                bytesRec += socket.Receive(load, load.Length, SocketFlags.None);
                buffer.AddRange(load);
            }

            return FormatResult(buffer.ToArray(), bytesRec);
        }

        protected string FormatResult(byte[] bytesToConvert, int bytesRecorded = -1)
        {
            string result = Encoding.ASCII.GetString(bytesToConvert, 0, bytesToConvert.Length);
            Console.WriteLine("Received {0} bytes: {1}", bytesRecorded, result);
            return result;
        }

        #region IDisposable Support
        protected bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing && socket != null && socket.Connected)
                {
                    socket.Shutdown(SocketShutdown.Both);
                    socket.Close();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.
                bytes = null;
                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~HTTPSocket() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}