namespace WebApiCore.Api.Configuration
{
    public class WeatherConfiguration
    {
        public string BaseUrl { get; set; }
    }
}